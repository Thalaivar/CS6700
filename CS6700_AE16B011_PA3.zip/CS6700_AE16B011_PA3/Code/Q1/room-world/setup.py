from setuptools import setup

setup(name='room_world',
    version='0.0.1',
    install_requires=['gym'])